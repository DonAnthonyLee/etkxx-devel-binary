/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: ThemeEngine.h
 * Description: Theme Engine Addon
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_THEME_ENGINE_H__
#define __ETK_THEME_ENGINE_H__

#include <etk/interface/View.h>

#ifdef __cplusplus /* Just for C++ */

enum {
	E_THEME_FOCUS_FLASH_BORDER = 1,
	E_THEME_FOCUS_FLASH_CONTENT = 1 << 1,
};

enum {
	E_THEME_NO_BORDER = 0,
	E_THEME_PLAIN_BORDER = 1,
	E_THEME_FANCY_BOX_BORDER = 2,
	E_THEME_FANCY_SCROLLVIEW_BORDER = 3,
	E_THEME_TEXT_CONTROL_BORDER = 4,
};


class EThemeEngine;

class _IMPEXP_ETK EThemeDrawer {
public:
	EThemeDrawer(EThemeEngine *engine);
	virtual ~EThemeDrawer();

	EThemeEngine*	Engine() const;

	EView*		Owner() const;
	void		SetOwner(EView *owner);

	// EView's functions BEGIN
	ERect		Bounds() const;
	ERect		Frame() const;

	bool		IsFocus() const;
	bool		IsEnabled() const;

	bool		IsPrinting() const;
	float		UnitsPerPixel() const;

	void		GetFont(EFont *font) const;
	void		GetFontHeight(e_font_height *height) const;

	void		PushState();
	void		PopState();

	void		GetClippingRegion(ERegion *clipping) const;
	void		ConstrainClippingRegion(const ERegion *clipping);
	void		ConstrainClippingRegion(ERect clipping);

	void		SetDrawingMode(e_drawing_mode mode);
	e_drawing_mode	DrawingMode() const;

	void		MovePenTo(EPoint pt);
	void		MovePenTo(float x, float y);
	void		MovePenBy(float dx, float dy);
	EPoint		PenLocation() const;

	void		SetPenSize(float size);
	float		PenSize() const;

	void		SetViewColor(e_rgb_color c);
	void		SetViewColor(euint8 r, euint8 g, euint8 b, euint8 a = 255);
	e_rgb_color	ViewColor() const;

	void		SetHighColor(e_rgb_color c);
	void		SetHighColor(euint8 r, euint8 g, euint8 b, euint8 a = 255);
	e_rgb_color	HighColor() const;

	void		SetLowColor(e_rgb_color c);
	void		SetLowColor(euint8 r, euint8 g, euint8 b, euint8 a = 255);
	e_rgb_color	LowColor() const;

	void		SetSquarePointStyle(bool state);
	bool		IsSquarePointStyle() const;
	void		StrokePoint(EPoint pt, e_pattern p = E_SOLID_HIGH);
	void		StrokePoints(const EPoint *pts, eint32 count, const euint8 *alpha = NULL, e_pattern p = E_SOLID_HIGH);

	void		StrokeLine(EPoint pt, e_pattern p = E_SOLID_HIGH);
	void		StrokeLine(EPoint pt0, EPoint pt1, e_pattern p = E_SOLID_HIGH);

	void		StrokePolygon(const EPolygon *aPolygon, bool closed = true, e_pattern p = E_SOLID_HIGH);
	void		StrokePolygon(const EPoint *ptArray, eint32 numPts, bool closed = true, e_pattern p = E_SOLID_HIGH);
	void		FillPolygon(const EPolygon *aPolygon, e_pattern p = E_SOLID_HIGH);
	void		FillPolygon(const EPoint *ptArray, eint32 numPts, e_pattern p = E_SOLID_HIGH);

	void		StrokeTriangle(EPoint pt1, EPoint pt2, EPoint pt3, e_pattern p = E_SOLID_HIGH);
	void		FillTriangle(EPoint pt1, EPoint pt2, EPoint pt3, e_pattern p = E_SOLID_HIGH);

	void		StrokeRect(ERect r, e_pattern p = E_SOLID_HIGH);
	void		FillRect(ERect r, e_pattern p = E_SOLID_HIGH);

	void		StrokeRects(const ERect *rects, eint32 count, e_pattern p = E_SOLID_HIGH);
	void		FillRects(const ERect *rects, eint32 count, e_pattern p = E_SOLID_HIGH);
	void		FillRegion(const ERegion *region, e_pattern p = E_SOLID_HIGH);

	void		StrokeRoundRect(ERect r, float xRadius, float yRadius, e_pattern p = E_SOLID_HIGH);
	void		FillRoundRect(ERect r, float xRadius, float yRadius, e_pattern p = E_SOLID_HIGH);

	void		StrokeArc(EPoint ctPt, float xRadius, float yRadius, float startAngle, float arcAngle, e_pattern p = E_SOLID_HIGH);
	void		StrokeArc(ERect r, float startAngle, float arcAngle, e_pattern p = E_SOLID_HIGH);
	void		FillArc(EPoint ctPt, float xRadius, float yRadius, float startAngle, float arcAngle, e_pattern p = E_SOLID_HIGH);
	void		FillArc(ERect r, float start_angle, float arc_angle, e_pattern p = E_SOLID_HIGH);

	void		StrokeEllipse(EPoint ctPt, float xRadius, float yRadius, e_pattern p = E_SOLID_HIGH);
	void		StrokeEllipse(ERect r, e_pattern p = E_SOLID_HIGH);
	void		FillEllipse(EPoint ctPt, float xRadius, float yRadius, e_pattern p = E_SOLID_HIGH);
	void		FillEllipse(ERect r, e_pattern p = E_SOLID_HIGH);

	void		DrawString(const char *aString, eint32 length = -1, float tabWidth = 0);
	void		DrawString(const char *aString, EPoint location, eint32 length = -1, float tabWidth = 0);
	void		DrawString(const char *aString, eint32 length, EPoint location, float tabWidth = 0);

	void		DrawBitmap(const EBitmap *bitmap);
	void		DrawBitmap(const EBitmap *bitmap, EPoint where);
	void		DrawBitmap(const EBitmap *bitmap, ERect destRect);
	void		DrawBitmap(const EBitmap *bitmap, ERect srcRect, ERect destRect);
	void		CopyBits(ERect srcRect, ERect destRect);
	// EView's functions END

private:
	EView *fOwner;
	EThemeEngine *fEngine;
};


class _IMPEXP_ETK EThemeBorderDrawer : public EThemeDrawer {
public:
	EThemeBorderDrawer(EThemeEngine *engine);
	virtual ~EThemeBorderDrawer();

	euint32			BorderStyle() const;
	void			SetBorderStyle(euint32 style);

	float			BorderWidth() const;
	void			SetBorderWidth(float width);

	virtual void		GetMargins(float *left, float *top, float *right, float *bottom) const = 0;
	virtual void		Draw(ERect frame) = 0;

private:
	euint32 fBorderStyle;
	float fBorderWidth;
};


class _IMPEXP_ETK EThemeButtonDrawer : public EThemeDrawer {
public:
	EThemeButtonDrawer(EThemeEngine *engine);
	virtual ~EThemeButtonDrawer();

	virtual const char*	Label() const;
	virtual void		SetLabel(const char *label);

	virtual void		GetPreferredSize(float *width, float *height) const = 0;
	virtual void		GetMargins(float *left, float *top, float *right, float *bottom) const = 0;

	virtual euint8		ShouldDoFocusFlash() const = 0;

	virtual void		DrawBorder(ERect frame, bool pushed, bool mouse_inside, euint8 focus_flash) = 0;
	virtual void		DrawLabel(ERect frame, bool pushed, bool mouse_inside, euint8 focus_flash) = 0;
	virtual void		ClearContent(ERect frame, bool pushed, bool mouse_inside, euint8 focus_flash) = 0;
	virtual void		Draw(ERect frame, bool pushed, bool mouse_inside, euint8 focus_flash) = 0;

private:
	char *fLabel;
};


class _IMPEXP_ETK EThemeScrollBarDrawer : public EThemeDrawer {
public:
	EThemeScrollBarDrawer(EThemeEngine *engine);
	virtual ~EThemeScrollBarDrawer();

	e_orientation		Orientation() const;
	void			SetOrientation(e_orientation direction);

	float			Value() const;
	void			SetValue(float value);

	void			GetRange(float *min, float *max) const;
	void			SetRange(float min, float max);

	virtual void		GetPreferredSize(float *width, float *height) = 0;
	virtual void		GetRespondent(ERect frame,
					      float *ratio, ERegion *drag,
					      ERegion *small_decrease, ERegion *small_increase,
					      ERegion *large_decrease, ERegion *large_increase) = 0;
	virtual void		Draw(ERect frame, EPoint mouse_position, bool mouse_down) = 0;

private:
	e_orientation fDirection;
	float fMinValue;
	float fMaxValue;
	float fCurValue;
};


class _IMPEXP_ETK EThemeStatusBarDrawer : public EThemeDrawer {
public:
	EThemeStatusBarDrawer(EThemeEngine *engine);
	virtual ~EThemeStatusBarDrawer();

	float			CurrentValue() const;
	void			SetCurrentValue(float value);

	float			MaxValue() const;
	void			SetMaxValue(float value);

	virtual void		GetPreferredSize(float *width, float *height) = 0;
	virtual void		Draw(ERect frame) = 0;

private:
	float fMaxValue;
	float fCurValue;
};


class _IMPEXP_ETK EThemeControlDrawer : public EThemeDrawer {
public:
	EThemeControlDrawer(EThemeEngine *engine);
	virtual ~EThemeControlDrawer();

	eint32			Value() const;
	void			SetValue(eint32 value);

	virtual void		GetPreferredSize(float *width, float *height) = 0;
	virtual void		Draw(ERect frame, bool highlight, bool pushed) = 0;

private:
	eint32 fValue;
};


class _IMPEXP_ETK EThemeSpinControlDrawer : public EThemeDrawer {
public:
	EThemeSpinControlDrawer(EThemeEngine *engine);
	virtual ~EThemeSpinControlDrawer();

	bool			TextHasBorder() const;
	void			SetTextHasBorder(bool state);

	virtual void		GetRespondent(ERect frame, ERegion *decrease, ERegion *increase) = 0;
	virtual void		GetMargins(float *left, float *top, float *right, float *bottom) const = 0;
	virtual void		Draw(ERect frame, EPoint mouse_position, bool mouse_down) = 0;

private:
	bool fTextHasBorder;
};


class _IMPEXP_ETK EThemeTextListControlDrawer : public EThemeDrawer {
public:
	EThemeTextListControlDrawer(EThemeEngine *engine);
	virtual ~EThemeTextListControlDrawer();

	bool			TextHasBorder() const;
	void			SetTextHasBorder(bool state);

	virtual void		GetRespondent(ERect frame, ERegion *popup) = 0;
	virtual void		GetMargins(float *left, float *top, float *right, float *bottom) const = 0;
	virtual void		Draw(ERect frame, EPoint mouse_position, bool mouse_down) = 0;

private:
	bool fTextHasBorder;
};


class _IMPEXP_ETK EThemeMenuFieldDrawer : public EThemeDrawer {
public:
	EThemeMenuFieldDrawer(EThemeEngine *engine);
	virtual ~EThemeMenuFieldDrawer();

	virtual void		GetMargins(float *left, float *top, float *right, float *bottom) const = 0;
	virtual void		Draw(ERect frame, bool highlight, bool pushed) = 0;
};


class _IMPEXP_ETK EThemeMenuDrawer : public EThemeDrawer {
public:
	EThemeMenuDrawer(EThemeEngine *engine);
	virtual ~EThemeMenuDrawer();

	// TODO
};


class _IMPEXP_ETK EThemeMiscDrawer : public EThemeDrawer {
public:
	EThemeMiscDrawer(EThemeEngine *engine);
	virtual ~EThemeMiscDrawer();

	virtual void		DrawTriangle(ERect rect, e_orientation direction, bool increase, bool filling) = 0;
	virtual void		DrawTriangleControl(ERect rect, e_orientation direction, bool increase, bool highlight, bool pushed) = 0;
};


class _IMPEXP_ETK EThemeEngine {
public:
	EThemeEngine();
	virtual ~EThemeEngine();

	bool					Lock();
	void					Unlock();

	virtual EThemeBorderDrawer*		BorderDrawer() = 0;
	virtual EThemeButtonDrawer*		ButtonDrawer() = 0;
	virtual EThemeScrollBarDrawer*		ScrollBarDrawer() = 0;
	virtual EThemeStatusBarDrawer*		StatusBarDrawer() = 0;
	virtual EThemeControlDrawer*		CheckBoxDrawer() = 0;
	virtual EThemeControlDrawer*		RadioButtonDrawer() = 0;
	virtual EThemeSpinControlDrawer*	SpinControlDrawer() = 0;
	virtual EThemeTextListControlDrawer*	TextListControlDrawer() = 0;
	virtual EThemeMenuFieldDrawer*		MenuFieldDrawer() = 0;
	virtual EThemeMenuDrawer*		MenuDrawer() = 0;

	virtual EThemeMiscDrawer*		MiscDrawer() = 0;

	virtual float				HorizontalScrollBarHeight();
	virtual float				VerticalScrollBarWidth();

private:
	ELocker fLocker;
};


_IMPEXP_ETK EThemeEngine *etk_get_theme_engine(void);


inline float EThemeEngine::HorizontalScrollBarHeight()
{
	// note: lock engine if needed
	return 14;
}


inline float EThemeEngine::VerticalScrollBarWidth()
{
	// note: lock engine if needed
	return 14;
}


#endif /* __cplusplus */

#endif /* __ETK_THEME_ENGINE_H__ */

