/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2006, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: ETKBuild.h
 * Description: Building environment
 * Warning: This is a generated file.  Please modify 'configure.in'
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_BUILD_H__
#define __ETK_BUILD_H__

#ifdef _MSC_VER
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#endif /* _MSC_VER */

#include <sys/types.h>
#include <limits.h>
#ifndef _MSC_VER
#include <unistd.h>
#endif /* _MSC_VER */
#include <float.h>

#define ETK_OS_WIN32




#define ETK_MAJOR_VERSION 0
#define ETK_MINOR_VERSION 4
#define ETK_MICRO_VERSION 3
#define ETK_INTERFACE_AGE 0
#define ETK_BINARY_AGE    403

#define ETK_THREAD_IMPL_WIN32
#define ETK_GRAPHICS_WIN32_BUILT_IN

#define ETK_LITTLE_ENDIAN

/* #undef ETK_BUILD_WITH_MEMORY_TRACING */

#undef HAVE_BZERO

#include <stddef.h>

#if __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 8)
#define __GNUC_EXTENSION __extension__
#else
#define __GNUC_EXTENSION
#endif

#define E_MINFLOAT	FLT_MIN
#define E_MAXFLOAT	FLT_MAX
#define E_MINDOUBLE	DBL_MIN
#define E_MAXDOUBLE	DBL_MAX
#define E_MINSHORT	SHRT_MIN
#define E_MAXSHORT	SHRT_MAX
#define E_MAXUSHORT	USHRT_MAX
#define E_MININT	INT_MIN
#define E_MAXINT	INT_MAX
#define E_MAXUINT	UINT_MAX
#define E_MINLONG	LONG_MIN
#define E_MAXLONG	LONG_MAX
#define E_MAXULONG	ULONG_MAX

typedef signed char eint8;
typedef unsigned char euint8;
#define E_MININT8	((eint8)0x80)
#define E_MAXINT8	((eint8)0x7f)
#define E_MAXUINT8	((euint8)0xff)

typedef signed short eint16;
typedef unsigned short euint16;
typedef unsigned short eunichar;
#define E_MININT16	((eint16)0x8000)
#define E_MAXINT16	((eint16)0x7fff)
#define E_MAXUINT16	((euint16)0xffff)

typedef signed int eint32;
typedef unsigned int euint32;
typedef unsigned int eunichar32;
#define E_MININT32	((eint32)0x80000000)
#define E_MAXINT32	((eint32)0x7fffffff)
#define E_MAXUINT32	((euint32)0xffffffff)


#ifndef _MSC_VER
__GNUC_EXTENSION typedef signed long long eint64;
__GNUC_EXTENSION typedef unsigned long long euint64;
#define E_INT64_CONSTANT(val)	(__GNUC_EXTENSION (val##LL))
#define E_MININT64	((eint64)E_INT64_CONSTANT(0x8000000000000000))
#define E_MAXINT64	((eint64)E_INT64_CONSTANT(0x7fffffffffffffff))
#define E_MAXUINT64	((euint64)E_INT64_CONSTANT(0xffffffffffffffff))
#else
typedef signed __int64 eint64;
typedef unsigned __int64 euint64;
#define E_INT64_CONSTANT(val)	(val##i64)
#define E_MININT64	((eint64)E_INT64_CONSTANT(0x8000000000000000))
#define E_MAXINT64	((eint64)E_INT64_CONSTANT(0x7fffffffffffffff))
#define E_MAXUINT64	((euint64)E_INT64_CONSTANT(0xffffffffffffffff))
#endif /* _MSC_VER */

#ifdef _MSC_VER
typedef long ssize_t;
#endif /* _MSC_VER */
#ifdef _WIN64
typedef euint64 e_address_t;
#else
typedef euint32 e_address_t;
#endif /* _WIN64 */

#if !defined(E_MAXPATH) && defined(PATH_MAX)
	#define E_MAXPATH	PATH_MAX
#endif


#if !defined(E_MAXPATH) && defined(_MSC_VER)
	#include <stdlib.h>
	#define E_MAXPATH	_MAX_PATH
#endif


#ifndef E_MAXPATH
	#error "CAN NOT define E_MAXPATH!"
#endif


#endif /* __ETK_BUILD_H__ */

