/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: PreferenceWindow.h
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_PREFERENCE_WINDOW_H__
#define __ETK_PREFERENCE_WINDOW_H__

#include <etk/interface/Button.h>
#include <etk/interface/Window.h>

#ifdef __cplusplus /* Just for C++ */


class _IMPEXP_ETK EPreferencePage : public EView {
public:
	EPreferencePage(ERect frame, const char *name, const char *path);
	virtual ~EPreferencePage();

	const char*		Path() const;

	virtual bool		Save() = 0;
	virtual bool		IsChanged() const = 0;

private:
	char *fPath;
};


class _IMPEXP_ETK EPreferenceWindow : public EWindow {
public:
	EPreferenceWindow(ERect frame, const char *title,
			  const char *button1_label,
			  const char *button2_label = NULL,
			  const char *button3_label = NULL,
			  e_button_width width = E_WIDTH_AS_USUAL);
	virtual ~EPreferenceWindow();

	eint32			CountPages() const;
	EPreferencePage*	PageAt(eint32 index);
	bool			AddPage(EPreferencePage *pageView);
	bool			RemovePage(EPreferencePage *pageView);

	EView*			BlankPageView() const;

	// use "ButtonAt(index)->SetMessage(new EMessage(cmd))" to override
	// default behavior:
	// 	button 1 - save the changes without verifying, then close the window
	// 	button 2 - apply the changes without verifying, stay on the course
	// 	button 3 - close the window without saving changes
	EButton			*ButtonAt(eint32 index) const;

	virtual void		MessageReceived(EMessage *msg);

private:
	EButton *fButtons[3];
};


#endif /* __cplusplus */

#endif /* __ETK_PREFERENCE_WINDOW_H__ */

