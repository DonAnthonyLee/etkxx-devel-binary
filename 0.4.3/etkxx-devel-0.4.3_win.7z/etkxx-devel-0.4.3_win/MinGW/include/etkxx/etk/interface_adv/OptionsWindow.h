/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: OptionsWindow.h
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_OPTIONS_WINDOW_H__
#define __ETK_OPTIONS_WINDOW_H__

#include <etk/interface/CompactView.h>
#include <etk/interface/Menu.h>
#include <etk/interface/Control.h>
#include <etk/storage/StorageDefs.h>
#include <etk/storage/FilePanel.h>
#include <etk/interface_adv/MovableWindow.h>

#ifdef __cplusplus /* Just for C++ */

class _IMPEXP_ETK EOptionsItem {
public:
	EOptionsItem();
	virtual ~EOptionsItem();

	void			SetName(EString name);
	bool			GetName(EString *name) const;

	virtual void		RestoreOptions(const EMessage *optMsg) = 0;
	virtual void		SaveOptions(EMessage *optMsg) = 0;
};


class _IMPEXP_ETK EOptionsItemView : public ECompactView, public EOptionsItem {
public:
	EOptionsItemView(const char *name, const char *label);
	virtual ~EOptionsItemView();

	const char*		Label() const;
	virtual void		SetLabel(const char *label);

	bool			IsToggleEnabled() const;
	void			SetToggleEnabled(bool state);
	void			SetToggleMessage(EMessage *toggleMsg);

	virtual float		LabelViewRatio() const;
	virtual float		ContentViewRatio() const;
	virtual void		SetLabelViewRatio(float ratio);
	virtual void		SetContentViewRatio(float ratio);

	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);

	virtual void		DrawAfterChildren(ERect updateRect);
	virtual void		AttachedToWindow();
};


class _IMPEXP_ETK EOptionsStringItemView : public EOptionsItemView {
public:
	EOptionsStringItemView(const char *name,
			       const char *label,
			       const char *initial_text);
	virtual ~EOptionsStringItemView();

	const char*		Text() const;
	void			SetText(const char *text);
	void			SetMessage(EMessage *msg);

	virtual float		ContentViewRatio() const;
	virtual void		SetContentViewRatio(float ratio);
	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);

	virtual void		AttachedToWindow();
};


class _IMPEXP_ETK EOptionsPathItemView : public EOptionsStringItemView {
public:
	EOptionsPathItemView(const char *name,
			     const char *label,
			     const char *initial_path,
			     euint32 node_flavors = E_ANY_NODE);
	virtual ~EOptionsPathItemView();

	void			SetPanelTitle(const char *title);
	void			SetPanelButtonLabel(e_file_panel_button btn, const char *label);

	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);
};


class _IMPEXP_ETK EOptionsNumberItemView : public EOptionsItemView {
public:
	EOptionsNumberItemView(const char *name,
			       const char *label,
			       double initial_value,
			       double min_value,
			       double max_value,
			       eint32 decimal_places = -1,
			       const char *suffix = NULL);
	virtual ~EOptionsNumberItemView();

	double			CurrentValue() const;
	void			SetCurrentValue(double v);
	void			SetRange(double min_v, double max_v);
	void			SetStep(double step_small, double step_large);
	void			SetDecimalPlaces(eint32 n);
	void			SetTextPrefix(const char *str);
	void			SetTextSuffix(const char *str);
	void			SetMessage(EMessage *msg);
	void			SetModificationMessage(EMessage *msg);

	virtual float		ContentViewRatio() const;
	virtual void		SetContentViewRatio(float ratio);
	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);

	virtual void		AttachedToWindow();
};


class _IMPEXP_ETK EOptionsMenuItemView : public EOptionsItemView {
public:
	EOptionsMenuItemView(const char *name,
			     const char *label,
			     EMenu *initial_menu);
	virtual ~EOptionsMenuItemView();

	EMenu*			Menu() const;
	void			SetMenu(EMenu *menu);

	virtual float		ContentViewRatio() const;
	virtual void		SetContentViewRatio(float ratio);
	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);

	virtual void		AttachedToWindow();
};


class _IMPEXP_ETK EOptionsCheckItemView : public EOptionsItemView {
public:
	EOptionsCheckItemView(const char *name,
			      const char *label,
			      eint32 value = E_CONTROL_ON,
			      bool traditional_style = false);
	virtual ~EOptionsCheckItemView();

	virtual void		SetLabel(const char *label);

	eint32			Value() const;
	void			SetValue(eint32 value);
	void			SetMessage(EMessage *msg);

	virtual float		ContentViewRatio() const;
	virtual void		SetContentViewRatio(float ratio);
	virtual void		GetItemPreferredSize(float *labelSize, float *contentSize);

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);
};


class _IMPEXP_ETK EOptionsGroupView : public EView, public EOptionsItem {
public:
	EOptionsGroupView(const char *name, const char *label);
	virtual ~EOptionsGroupView();

	const char*		Label() const;
	virtual void		SetLabel(const char *label);

	bool			IsExpanded() const;
	void			SetExpanded(bool state);
	void			SetExpandable(bool state);

	eint32			CountItemViews() const;
	void			AddItemView(EView *item_view);
	EView*			ItemViewAt(eint32 index) const;

	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);

	virtual void		Draw(ERect updateRect);
	virtual void		GetPreferredSize(float *width, float *height);
	virtual void		FrameResized(float new_width, float new_height);
	virtual void		AttachedToWindow();
	virtual void		MessageReceived(EMessage *msg);
	virtual void		MouseUp(EPoint where);

private:
	char *fLabel;
	bool fExpanded;
	bool fExpandable;
};


class _IMPEXP_ETK EOptionsWindow : public EMovableWindow {
public:
	EOptionsWindow(const char *title);
	virtual ~EOptionsWindow();

	eint32			CountOptionsGroups() const;
	eint32			AddOptionsGroup(EView *groupView);
	EView*			RemoveOptionsGroup(eint32 index);
	EView*			OptionsGroupViewAt(eint32 index) const;

	bool			IsOptionsRestored() const;
	virtual void		RestoreOptions(const EMessage *optMsg);
	virtual void		SaveOptions(EMessage *optMsg);
	virtual EMessage*	LoadOptions();

	virtual void		ResizeToPreferred();

	virtual void		SetTitle(const char *title);
	virtual bool		QuitRequested();
	virtual void		Show();

	static bool		FindOptions(EMessage *optMsg, const char *path, EMessage *msg);

private:
	bool fOptionsRestored;
	eint32 fGroupsCount;
};

#endif /* __cplusplus */

#endif /* __ETK_OPTIONS_WINDOW_H__ */

