/* --------------------------------------------------------------------------
 * 
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 * File: InterfaceKit.h
 * 
 * --------------------------------------------------------------------------*/

#include <etk/interface/GraphicsDefs.h>
#include <etk/interface/InterfaceDefs.h>
#include <etk/interface/Point.h>
#include <etk/interface/Rect.h>

#ifndef ETK_LITE_BUILD
#include <etk/interface/Polygon.h>
#include <etk/interface/Region.h>
#include <etk/interface/Font.h>
#include <etk/interface/Screen.h>
#include <etk/interface/Window.h>
#include <etk/interface/View.h>
#include <etk/interface/CompactView.h>
#include <etk/interface/ScrollBar.h>
#include <etk/interface/ScrollView.h>
#include <etk/interface/Control.h>
#include <etk/interface/ColorControl.h>
#include <etk/interface/SpinControl.h>
#include <etk/interface/Button.h>
#include <etk/interface/Alert.h>
#include <etk/interface/CheckBox.h>
#include <etk/interface/RadioButton.h>
#include <etk/interface/MenuItem.h>
#include <etk/interface/Menu.h>
#include <etk/interface/PopUpMenu.h>
#include <etk/interface/MenuBar.h>
#include <etk/interface/MenuField.h>
#include <etk/interface/StringView.h>
#include <etk/interface/Box.h>
#include <etk/interface/StatusBar.h>
#include <etk/interface/TextEditable.h>
#include <etk/interface/TextControl.h>
#include <etk/interface/ListItem.h>
#include <etk/interface/ListView.h>
#include <etk/interface/OutlineListView.h>
#include <etk/interface/TabView.h>
#include <etk/interface/TextView.h>
#include <etk/interface/Bitmap.h>
#include <etk/interface/ToolTip.h>
#include <etk/interface/Input.h>
#include <etk/interface/DividerControl.h>
#include <etk/interface/TextListControl.h>
#endif

