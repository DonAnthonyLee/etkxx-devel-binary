/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2014, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: CompactView.h
 * Description: ECompactView --- View support ratio and orientation
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_COMPACT_VIEW_H__
#define __ETK_COMPACT_VIEW_H__

#include <etk/interface/View.h>

#ifdef __cplusplus /* Just for C++ */

class _IMPEXP_ETK ECompactView : public EView {
public:
	ECompactView(ERect frame,
		     const char *name,
		     e_orientation orientation,
		     euint32 resizingMode,
		     euint32 flags);
	virtual ~ECompactView();

	// ratio < 0 means child is fixed size in (-ratio) pixels
	// ratio = 0 means child always be resized to preferred size
	// ratio = NAN means child's minimum size is preferred size, it will take the rest when it's the last expandable
	// 0 < ratio <= 1 means child takes (ratio*100) percents of parent's view
	// 1 < ratio < 2 means child always keep orginal size
	// ratio >= 2 means child's minimum size is (ratio) pixels, it will take the rest when it's the last expandable
	void		AddChild(EView *child, float ratio, float spacing = 0);
	void		AddChild(EView *child, EView *childNextSibling, float ratio, float spacing = 0);

	float		GetChildRatio(EView *child) const;
	bool		SetChildRatio(EView *child, float ratio);

	float		GetChildSpacing(EView *child) const;
	bool		SetChildSpacing(EView *child, float spacing);

	e_orientation	Orientation() const;
	virtual void	SetOrientation(e_orientation orientation);

	bool		IsInvertedSequence() const;
	virtual void	SetInvertedSequence(bool state);

	virtual void	SetMargins(float left, float top, float right, float bottom);
	void		GetMargins(float *left, float *top, float *right, float *bottom) const;

	// UpdateLayout: called from child which preferred size changed
	void		UpdateLayout();

	virtual void	GetPreferredSize(float *width, float *height);

protected:
	virtual void	ChildRemoved(EView *child);

private:
	e_orientation fOrientation;
	bool fInvertedSequence;
};

#endif /* __cplusplus */

#endif /* __ETK_COMPACT_VIEW_H__ */

