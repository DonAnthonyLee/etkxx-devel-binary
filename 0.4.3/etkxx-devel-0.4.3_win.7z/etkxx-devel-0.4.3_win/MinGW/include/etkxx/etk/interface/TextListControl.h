/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: TextListControl.h
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_TEXT_LIST_CONTROL_H__
#define __ETK_TEXT_LIST_CONTROL_H__

#include <etk/interface/TextControl.h>

#ifdef __cplusplus /* Just for C++ */

class EChoiceList;

class _IMPEXP_ETK ETextListControl : public ETextControl {
public:
	ETextListControl(ERect frame,
		      const char *name,
		      const char *label,
		      const char *text,
		      EMessage *message,
		      EChoiceList *choiceList = NULL,
		      bool ownChoiceList = true,
		      euint32 resizeMode = E_FOLLOW_LEFT | E_FOLLOW_TOP,
		      euint32 flags = E_WILL_DRAW | E_FRAME_EVENTS | E_NAVIGABLE);
	virtual ~ETextListControl();

	EChoiceList*		ChoiceList() const;
	virtual void		SetChoiceList(EChoiceList *list, bool ownList = true);
	virtual void		ChoiceListChanged();

	virtual void		Draw(ERect updateRect);
	virtual void		KeyDown(const char *bytes, eint32 numBytes);
	virtual void		KeyUp(const char *bytes, eint32 numBytes);
	virtual void		MouseDown(EPoint where);
	virtual void		MouseUp(EPoint where);
	virtual void		MouseMoved(EPoint where, euint32 code, const EMessage *msg);
	virtual void		MakeFocus(bool focusState = true);

protected:
	virtual void		GetBorderMargins(ERect *margins) const;

private:
	EChoiceList *fChoiceList;
	bool fOwnsChoiceList;
	EPoint fMousePosition;
	bool fMousePushed;
	ERegion fTrackingRegion;
	bool fTrackingState;
};


class _IMPEXP_ETK EChoiceList : public EArchivable {
public:
	EChoiceList();
	virtual ~EChoiceList();

	virtual eint32		CountChoices() const = 0;
	virtual const char*	GetChoiceAt(eint32 index, eint32 *key = NULL) const = 0;
	virtual const char*	GetChoiceByKey(eint32 key, eint32 *index = NULL) const = 0;
	virtual e_status_t	FindMatch(const char *prefix,
					  eint32 startIndex,
					  eint32 *matchIndex,
					  EString *completionText,
					  eint32 *matchKey) const = 0;

	void			SetOwner(ETextListControl *owner);
	ETextListControl*	Owner() const;

	bool Lock();
	void Unlock();

private:
	ELocker fLocker;
	ETextListControl *fOwner;
};


class _IMPEXP_ETK EStringChoiceList : public EChoiceList {
public:
	EStringChoiceList();
	virtual ~EStringChoiceList();

	virtual eint32		CountChoices() const;
	virtual const char*	GetChoiceAt(eint32 index, eint32 *key = NULL) const;
	virtual const char*	GetChoiceByKey(eint32 key, eint32 *index = NULL) const;
	virtual e_status_t	FindMatch(const char *prefix,
					  eint32 startIndex,
					  eint32 *matchIndex,
					  EString *completionText,
					  eint32 *matchKey) const;

	e_status_t		AddChoice(const char *string, eint32 key);
	e_status_t		AddChoice(const char *string, eint32 key, eint32 index);

	e_status_t		RemoveChoice(const char *string);
	e_status_t		RemoveChoiceAt(eint32 index);
	e_status_t		RemoveChoiceByKey(eint32 key);

	// TODO: sort

private:
	EList fList;
	eint32 fAutoKey;
};


#endif /* __cplusplus */

#endif /* __ETK_TEXT_LIST_CONTROL_H__ */

