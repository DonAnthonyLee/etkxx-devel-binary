#ifndef __LITE_BEAPI_OS_H__
#define __LITE_BEAPI_OS_H__

#include <be/support/SupportDefs.h>

#define B_SYSTEM_TIMEBASE		E_SYSTEM_TIMEBASE

#define snooze(us)			etk_snooze(us)
#define snooze_until(t, b)		etk_snooze_util(t, b)

#define real_time_clock()		etk_real_time_clock()
#define real_time_clock_usecs()		etk_real_time_clock_usecs()
#define system_time()			etk_system_time()

#define B_LOW_PRIORITY			E_LOW_PRIORITY
#define B_NORMAL_PRIORITY		E_NORMAL_PRIORITY
#define B_DISPLAY_PRIORITY		E_DISPLAY_PRIORITY
#define	B_URGENT_DISPLAY_PRIORITY	E_URGENT_DISPLAY_PRIORITY
#define	B_REAL_TIME_DISPLAY_PRIORITY	E_REAL_TIME_DISPLAY_PRIORITY
#define	B_URGENT_PRIORITY		E_URGENT_PRIORITY
#define B_REAL_TIME_PRIORITY		E_REAL_TIME_PRIORITY


/* TODO */

#endif /* __LITE_BEAPI_OS_H__ */

