#ifndef __LITE_BEAPI_KERNEL_KIT_H__
#define __LITE_BEAPI_KERNEL_KIT_H__

#include <be/kernel/OS.h>

#endif /* __LITE_BEAPI_KERNEL_KIT_H__ */

