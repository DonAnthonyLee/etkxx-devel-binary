#ifndef __LITE_BEAPI_STRING_H__
#define __LITE_BEAPI_STRING_H__

#if defined(_WIN32)
#if defined(__GNUC__)
#include_next <string.h>
#elif defined(SYS_STRING_H_PATH)
#include SYS_STRING_H_PATH
#endif
#endif

#include <be/support/SupportDefs.h>

#ifdef __cplusplus

// class
#define BString			EString

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_STRING_H__ */

