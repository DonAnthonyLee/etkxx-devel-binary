#ifndef __LITE_BEAPI_TYPE_CONSTANTS_H__
#define __LITE_BEAPI_TYPE_CONSTANTS_H__

#include <be/support/SupportDefs.h>

#endif /* __LITE_BEAPI_TYPE_CONSTANTS_H__ */

