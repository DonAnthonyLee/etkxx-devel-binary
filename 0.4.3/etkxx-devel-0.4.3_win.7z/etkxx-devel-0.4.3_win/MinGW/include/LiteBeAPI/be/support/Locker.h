#ifndef __LITE_BEAPI_LOCKER_H__
#define __LITE_BEAPI_LOCKER_H__

#include <be/support/SupportDefs.h>

#ifdef __cplusplus

// class
#define BLocker				ELocker

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_LOCKER_H__ */

