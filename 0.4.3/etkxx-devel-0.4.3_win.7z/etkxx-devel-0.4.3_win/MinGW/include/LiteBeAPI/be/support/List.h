#ifndef __LITE_BEAPI_LIST_H__
#define __LITE_BEAPI_LIST_H__

#include <be/support/SupportDefs.h>

#ifdef __cplusplus

// class
#define BList			EList

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_LIST_H__ */

