#ifndef __LITE_BEAPI_BEEP_H__
#define __LITE_BEAPI_BEEP_H__

#include <be/support/SupportDefs.h>

#define beep()			B_OK

#endif /* __LITE_BEAPI_BEEP_H__ */

