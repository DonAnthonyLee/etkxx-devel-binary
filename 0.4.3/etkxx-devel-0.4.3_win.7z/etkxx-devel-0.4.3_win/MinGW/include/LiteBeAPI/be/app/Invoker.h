#ifndef __LITE_BEAPI_INVOKER_H__
#define __LITE_BEAPI_INVOKER_H__

#include <be/app/Messenger.h>

#ifdef __cplusplus

// class
#define BInvoker			EInvoker

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_INVOKER_H__ */

