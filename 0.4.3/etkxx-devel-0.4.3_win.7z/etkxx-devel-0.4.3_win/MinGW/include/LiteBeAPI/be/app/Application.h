#ifndef __LITE_BEAPI_APPLICATION_H__
#define __LITE_BEAPI_APPLICATION_H__

#include <be/app/Looper.h>
#include <be/app/MessageRunner.h>

#ifdef __cplusplus

// class
#define BApplication			EApplication

#define be_app				etk_app
#define be_app_messenger		etk_app_messenger

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_APPLICATION_H__ */

