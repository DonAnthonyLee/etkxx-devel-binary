#ifndef __LITE_BEAPI_MESSAGE_H__
#define __LITE_BEAPI_MESSAGE_H__

#include <be/app/Messenger.h>

#ifdef __cplusplus

// class
#define BMessage			EMessage

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_MESSAGE_H__ */

