#ifndef __LITE_BEAPI_MESSAGE_QUEUE_H__
#define __LITE_BEAPI_MESSAGE_QUEUE_H__

#include <be/support/Locker.h>
#include <be/app/Message.h>

#ifdef __cplusplus

// class
#define BMessageQueue		EMessageQueue

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_MESSAGE_QUEUE_H__ */

