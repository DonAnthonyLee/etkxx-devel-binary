#ifndef __LITE_BEAPI_LOOPER_H__
#define __LITE_BEAPI_LOOPER_H__

#include <be/app/Handler.h>
#include <be/app/MessageQueue.h>

#ifdef __cplusplus

// class
#define BLooper				ELooper

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_LOOPER_H__ */

