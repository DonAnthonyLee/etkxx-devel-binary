#ifndef __LITE_BEAPI_SCROLL_BAR_H__
#define __LITE_BEAPI_SCROLL_BAR_H__

#include <be/interface/View.h>

#ifdef __cplusplus

// class
#define BScrollBar			EScrollBar

#endif /* __cplusplus */

/* others */
#define B_V_SCROLL_BAR_WIDTH		E_V_SCROLL_BAR_WIDTH
#define B_H_SCROLL_BAR_HEIGHT		E_H_SCROLL_BAR_HEIGHT

#endif /* __LITE_BEAPI_SCROLL_BAR_H__ */

