#ifndef __LITE_BEAPI_INPUT_H__
#define __LITE_BEAPI_INPUT_H__

#include <be/app/Messenger.h>

#ifdef __cplusplus

// class

#endif /* __cplusplus */

/* others */
#define input_method_op				eint32
#define B_INPUT_METHOD_STARTED			E_INPUT_METHOD_STARTED
#define B_INPUT_METHOD_STOPPED			E_INPUT_METHOD_STOPPED
#define B_INPUT_METHOD_CHANGED			E_INPUT_METHOD_CHANGED
#define B_INPUT_METHOD_LOCATION_REQUEST		E_INPUT_METHOD_LOCATION_REQUEST

#endif /* __LITE_BEAPI_INPUT_H__ */

