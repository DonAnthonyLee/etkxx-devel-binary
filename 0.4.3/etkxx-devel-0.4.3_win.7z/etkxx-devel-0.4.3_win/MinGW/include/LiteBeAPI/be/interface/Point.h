#ifndef __LITE_BEAPI_POINT_H__
#define __LITE_BEAPI_POINT_H__

#include <be/support/SupportDefs.h>

#ifdef __cplusplus

// class
#define BPoint		EPoint
#define B_ORIGIN	E_ORIGIN

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_POINT_H__ */

