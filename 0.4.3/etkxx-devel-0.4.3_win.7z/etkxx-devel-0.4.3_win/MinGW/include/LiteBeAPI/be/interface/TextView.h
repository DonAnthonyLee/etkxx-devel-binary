#ifndef __LITE_BEAPI_TEXT_VIEW_H__
#define __LITE_BEAPI_TEXT_VIEW_H__

#include <be/interface/View.h>

#ifdef __cplusplus

// class
#define BTextView		ETextView

#define text_run		e_text_run
#define text_run_array		e_text_run_array

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_TEXT_VIEW_H__ */

