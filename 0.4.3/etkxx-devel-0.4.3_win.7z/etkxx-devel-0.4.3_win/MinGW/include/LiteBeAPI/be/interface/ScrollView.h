#ifndef __LITE_BEAPI_SCROLL_VIEW_H__
#define __LITE_BEAPI_SCROLL_VIEW_H__

#include <be/interface/ScrollBar.h>

#ifdef __cplusplus

#define BScrollView	EScrollView

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_SCROLL_VIEW_H__ */

