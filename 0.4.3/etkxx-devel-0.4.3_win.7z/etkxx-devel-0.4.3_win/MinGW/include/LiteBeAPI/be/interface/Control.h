#ifndef __LITE_BEAPI_CONTROL_H__
#define __LITE_BEAPI_CONTROL_H__

#include <be/app/Invoker.h>
#include <be/interface/View.h>

#ifdef __cplusplus

// class
#define BControl		EControl

#endif /* __cplusplus */

/* others */
#define B_CONTROL_OFF		E_CONTROL_OFF
#define B_CONTROL_ON		E_CONTROL_ON

#endif /* __LITE_BEAPI_CONTROL_H__ */

