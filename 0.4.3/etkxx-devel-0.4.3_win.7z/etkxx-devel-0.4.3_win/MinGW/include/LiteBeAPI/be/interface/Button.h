#ifndef __LITE_BEAPI_BUTTON_H__
#define __LITE_BEAPI_BUTTON_H__

#include <be/interface/Control.h>

#ifdef __cplusplus

// class
#define BButton			EButton

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_BUTTON_H__ */

