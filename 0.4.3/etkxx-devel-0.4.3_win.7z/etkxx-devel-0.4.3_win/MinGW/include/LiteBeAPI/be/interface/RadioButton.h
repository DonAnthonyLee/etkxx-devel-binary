#ifndef __LITE_BEAPI_RADIO_BUTTON_H__
#define __LITE_BEAPI_RADIO_BUTTON_H__

#include <be/interface/Control.h>

#ifdef __cplusplus

// class
#define BRadioButton		ERadioButton

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_RADIO_BUTTON_H__ */

