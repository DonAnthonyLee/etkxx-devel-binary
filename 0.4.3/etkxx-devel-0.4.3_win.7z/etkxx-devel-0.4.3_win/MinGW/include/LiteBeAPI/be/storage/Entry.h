#ifndef __LITE_BEAPI_ENTRY_H__
#define __LITE_BEAPI_ENTRY_H__

#ifdef __cplusplus

// class
#define BEntry			EEntry

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_ENTRY_H__ */

