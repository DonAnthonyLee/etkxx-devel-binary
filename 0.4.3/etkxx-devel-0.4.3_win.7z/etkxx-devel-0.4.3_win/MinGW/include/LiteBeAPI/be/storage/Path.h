#ifndef __LITE_BEAPI_PATH_H__
#define __LITE_BEAPI_PATH_H__

#ifdef __cplusplus

// class
#define BPath			EPath

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_PATH_H__ */

