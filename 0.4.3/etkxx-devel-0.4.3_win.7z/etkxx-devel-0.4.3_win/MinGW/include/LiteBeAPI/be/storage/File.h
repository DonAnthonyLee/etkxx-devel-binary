#ifndef __LITE_BEAPI_FILE_H__
#define __LITE_BEAPI_FILE_H__

#ifdef __cplusplus

// class
#define BFile			EFile

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_FILE_H__ */

