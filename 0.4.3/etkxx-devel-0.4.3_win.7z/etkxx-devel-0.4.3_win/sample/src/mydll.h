#ifndef __MYDLL_H__
#define __MYDLL_H__

#include <etkxx.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


_EXPORT void* instantiate_module();


#ifdef __cplusplus
} // extern "C"
#endif /* __cplusplus */

#endif /* __MYDLL_H__ */

