#include "mydll.h"


extern "C" _EXPORT void* instantiate_module()
{
	return NULL;
}

