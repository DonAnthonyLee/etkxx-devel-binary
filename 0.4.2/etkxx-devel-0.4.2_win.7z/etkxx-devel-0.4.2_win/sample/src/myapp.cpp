/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2012, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: compactview-test.cpp
 *
 * --------------------------------------------------------------------------*/

#include <etkxx.h>


class TWindow : public EWindow {
public:
	TWindow(ERect frame,
		const char *title,
		e_window_type type,
		euint32 flags,
		euint32 workspace = E_CURRENT_WORKSPACE);
	virtual ~TWindow();

	virtual bool QuitRequested();

private:
	bool quited;
};


class TApplication : public EApplication {
public:
	TApplication();
	virtual ~TApplication();

	virtual void	ReadyToRun();
};


#define SPACING 2
TWindow::TWindow(ERect frame, const char *title, e_window_type type, euint32 flags, euint32 workspace)
	: EWindow(frame, title, type, flags, workspace), quited(false)
{
	EAutolock <ELooper>autolock(this);
	Run();

	ECompactView *view_top = new ECompactView(frame.OffsetToCopy(E_ORIGIN), NULL, E_VERTICAL, E_FOLLOW_ALL, 0);
	AddChild(view_top);

	view_top->AddChild(new EButton(ERect(), NULL, "10%", NULL), 0.1f, SPACING);

	ECompactView *aView = new ECompactView(ERect(), NULL, E_HORIZONTAL, 0, 0);
	view_top->AddChild(aView, 0.75, SPACING);

	for(eint32 m = 0; m < 3 && aView != NULL; m++)
	{
		ECompactView *nView = NULL;
		for(eint32 k = 0; k < 4; k++)
		{
			if(k == m + 1 && m != 2)
			{
				nView = new ECompactView(ERect(), NULL, (m % 2 == 0 ? E_VERTICAL : E_HORIZONTAL), 0, 0);
				aView->AddChild(nView, 0.1f * (float)(4 - k), SPACING);
			}
			else
			{
				EString str;
				str << 10 * (4 - k) << "%";
#if 0
				EStringView *strView = new EStringView(ERect(), NULL, str, 0);
				strView->SetAlignment(E_ALIGN_CENTER);
				strView->SetVerticalAlignment(E_ALIGN_MIDDLE);
				strView->SetViewColor(255 - m * 10 - k * 20,
						      255 - (m + 1) * 20 - (k + 1) * 20,
						      255 - (m + 2) * 30 - (k + 2) * 20);
				aView->AddChild(strView, 0.1 * (float)(4 - k), SPACING);
#else
				EView *cptView = new EView(ERect(), NULL, E_FOLLOW_NONE, 0);
				cptView->SetViewColor(255 - m * 10 - k * 20,
						      255 - (m + 1) * 20 - (k + 1) * 20,
						      255 - (m + 2) * 30 - (k + 2) * 20);
				aView->AddChild(cptView, 0.1f * (float)(4 - k), SPACING);

				str.Prepend("ratio: ");
				EToolTip::Default()->SetToolTipInfo(EMessenger(cptView), new EToolTipInfo(str.String()));
#endif
			}
		}
		aView = nView;
	}

	view_top->AddChild(new EButton(ERect(), NULL, "15%", NULL), 0.15f);

	float w = 800, h = 600;
	view_top->GetPreferredSize(&w, &h);
	ResizeTo(w, h);
}


TWindow::~TWindow()
{
}


bool
TWindow::QuitRequested()
{
	if(quited) return true;
	etk_app->PostMessage(E_QUIT_REQUESTED);
	quited = true;
	return false;
}


TApplication::TApplication()
	: EApplication("application/x-vnd.lee-test-app")
{
}


TApplication::~TApplication()
{
}


void
TApplication::ReadyToRun()
{
	TWindow *win = new TWindow(ERect(100, 100, 200, 200), "CompactView Test", E_TITLED_WINDOW, 0);

	win->Lock();
	win->Show();
	win->Unlock();
}


int main(int argc, char **argv)
{
	TApplication app;
	app.Run();

	return 0;
}


#if defined(_WIN32) && !(defined(_MSC_VER) && defined(_DEBUG))
#include <windows.h>
int _stdcall WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	return main(__argc, __argv);
}
#endif // defined(_WIN32) && !(defined(_MSC_VER) && defined(_DEBUG))

