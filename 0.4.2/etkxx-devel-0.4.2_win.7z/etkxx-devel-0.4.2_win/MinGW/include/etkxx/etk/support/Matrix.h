/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2013, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: EMatrix.h
 * Description: EMatrix --- matrix operation
 *
 * --------------------------------------------------------------------------*/


#ifndef __ETK_MATRIX_H__
#define __ETK_MATRIX_H__

#include <etk/support/SupportDefs.h>

#ifdef __cplusplus /* Just for C++ */

class _IMPEXP_ETK EMatrix
{
public:
	EMatrix();
	EMatrix(euint32 m, euint32 n, const double *data = NULL);
	EMatrix(const EMatrix &m_src);
	~EMatrix();

	bool IsValid() const;
	void MakeInvalid();

	EMatrix operator+(const EMatrix &m1) const;
	EMatrix operator-(const EMatrix &m1) const;
	EMatrix operator*(double k) const;
	EMatrix operator*(const EMatrix &m1) const;
	EMatrix operator&(const EMatrix &m1) const;
	EMatrix operator|(const EMatrix &m1) const;

	EMatrix &operator=(const EMatrix &m_src);
	EMatrix &operator+=(const EMatrix &m1);
	EMatrix &operator-=(const EMatrix &m1);
	EMatrix &operator*=(double k);
	EMatrix &operator*=(const EMatrix &m1);
	EMatrix &operator&=(const EMatrix &m1);
	EMatrix &operator|=(const EMatrix &m1);

	bool operator==(int v) const; // v = 0, 1
	EMatrix &operator=(int v); // v = 0, 1
	double &operator()(euint32 m1, euint32 n1);
	double operator()(euint32 m1, euint32 n1) const;

	EMatrix& Set(euint32 m, euint32 n, const double *data);
	euint32 Rows() const;
	euint32 Columns() const;
	const double* Data() const;

	bool Set(euint32 m1, euint32 n1, double num);
	bool Get(euint32 m1, euint32 n1, double *num) const;

	EMatrix Get(euint32 m_start, euint32 n_start, euint32 m_len, euint32 n_len) const;
	EMatrix& Truncated(euint32 m_start, euint32 n_start, euint32 m_len, euint32 n_len);
	void RemoveRow(euint32 m_start, euint32 count = 1);

	bool Plus(const EMatrix &m1);
	bool Subtract(const EMatrix &m1);
	void Multiply(double k);
	bool MultiplyLeft(const EMatrix ml);
	bool MultiplyRight(const EMatrix mr);

	EMatrix PlusCopy(const EMatrix &m1) const;
	EMatrix SubtractCopy(const EMatrix &m1) const;
	EMatrix MultiplyCopy(double k) const;
	EMatrix MultiplyLeftCopy(const EMatrix &ml) const;
	EMatrix MultiplyRightCopy(const EMatrix &mr) const;

	EMatrix CofactorOfDeterminant(euint32 m1, euint32 n1) const;
	double ValueOfDeterminant() const;

	EMatrix& Transpose();
	EMatrix TransposeCopy() const;

	bool Inverse();
	EMatrix InverseCopy() const;

	EMatrix& RREF();
	EMatrix RREFCopy() const;

	euint32 Ranks() const;

	e_status_t LinearSolve(const EMatrix &b, EMatrix &x) const;

	void ZeroLessThan(double value, bool abs);
	void PrintToStream(const char *name = NULL) const;

private:
	euint32 m;
	euint32 n;
	double *data;

	double* RowData(euint32 m1) const;
	euint32 FindRowFirstNotLessThan(euint32 m1, euint32 n_from, double value, bool abs) const;
	euint32 FindColumnFirstNotLessThan(euint32 n1, euint32 m_from, double value, bool abs) const;

	void SwapRow(euint32 m1, euint32 m2);
	void RowPlus(euint32 m_dst, euint32 m_src);
	void RowPlus(euint32 m_dst, euint32 m_src, double multi_src);
	void RowMultipy(euint32 m_dst, double multi);

	void SwapColumn(euint32 n1, euint32 n2);
	void ColumnPlus(euint32 n_dst, euint32 n_src);
	void ColumnPlus(euint32 n_dst, euint32 n_src, double multi_src);
	void ColumnMultipy(euint32 n_dst, double multi);
};

#endif /* __cplusplus */

#endif // __ETK_MATRIX_H__


