/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: MovableWindow.h
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_MOVABLE_WINDOW_H__
#define __ETK_MOVABLE_WINDOW_H__

#include <etk/interface/Window.h>

#ifdef __cplusplus /* Just for C++ */

class _IMPEXP_ETK EMovableWindow : public EWindow {
public:
	EMovableWindow(ERect frame,
		       const char *title,
		       e_window_type type,
		       euint32 flags,
		       euint32 workspace = E_CURRENT_WORKSPACE);
	EMovableWindow(ERect frame,
		       const char *title,
		       e_window_look look,
		       e_window_feel feel,
		       euint32 flags,
		       euint32 workspace = E_CURRENT_WORKSPACE);
	virtual ~EMovableWindow();

	void		SetActivateWhenFocus(bool state);
	void		SetAwareArea(ERect rect);
	void		SetAwareArea(ERegion *region);
	void		SetAllAware();

	virtual void	DispatchMessage(EMessage *msg, EHandler *target);

private:
	bool fActivateWhenFocus;
	bool fTracking;
	EPoint fTrackPos;
	ERegion fAwareArea;
};


inline void
EMovableWindow::SetAllAware()
{
	SetAwareArea(ERect());
}

#endif /* __cplusplus */

#endif /* __ETK_MOVABLE_WINDOW_H__ */

