/* --------------------------------------------------------------------------
 *
 * ETK++ --- The Easy Toolkit for C++ programing
 * Copyright (C) 2004-2015, Anthony Lee, All Rights Reserved
 *
 * ETK++ library is a freeware; it may be used and distributed according to
 * the terms of The MIT License.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * File: SpinControl.h
 *
 * --------------------------------------------------------------------------*/

#ifndef __ETK_SPIN_CONTROL_H__
#define __ETK_SPIN_CONTROL_H__

#include <etk/interface/TextControl.h>

#ifdef __cplusplus /* Just for C++ */

enum {
	E_SPIN_CONTROL_NO_BUTTONS = 0x1 << 16,
	E_SPIN_CONTROL_POPUP_SLIDER_WHEN_FOCUS = 0x1 << 17,
};

class _IMPEXP_ETK ESpinControl : public ETextControl {
public:
	ESpinControl(ERect frame,
		     const char *name,
		     const char *label,
		     double value,
		     eint32 decimal_places,
		     EMessage *message,
		     euint32 resizeMode = E_FOLLOW_LEFT | E_FOLLOW_TOP,
		     euint32 flags = E_WILL_DRAW | E_FRAME_EVENTS | E_NAVIGABLE);
	virtual ~ESpinControl();

	virtual void	SetCurrentValue(double v);
	virtual void	SetRange(double min_v, double max_v);
	virtual void	SetStep(double step_small, double step_large);
	double		CurrentValue() const;
	double		MaxValue() const;
	double		MinValue() const;
	double		Step(bool large = false) const;

	virtual void	SetDecimalPlaces(eint32 n);
	eint32		DecimalPlaces() const;

	virtual void	SetTextPrefix(const char *str);
	virtual void	SetTextSuffix(const char *str);
	const char*	TextPrefix() const;
	const char*	TextSuffix() const;

	virtual void	Draw(ERect updateRect);
	virtual void	KeyDown(const char *bytes, eint32 numBytes);
	virtual void	MouseDown(EPoint where);
	virtual void	MouseUp(EPoint where);
	virtual void	MouseMoved(EPoint where, euint32 code, const EMessage *msg);
	virtual void	MakeFocus(bool focusState = true);
	virtual void	WindowActivated(bool state);
	virtual void	Pulse();
	virtual void	GetPreferredSize(float *width, float *height);

protected:
	virtual void	GetBorderMargins(ERect *margins) const;

private:
	double fValueCur;
	double fValueMax;
	double fValueMin;
	double fValueStepSmall;
	double fValueStepLarge;
	eint32 fDecimalPlaces;
	char *fTextPrefix;
	char *fTextSuffix;

	bool fTracking;
	ERegion fTrackingRegion;
	eint32 fTrackingState;
	EPoint fMousePosition;
	e_bigtime_t fTrackingTimestamp;

	void doChangeValue(eint32 state);
	void doUpdateContent(bool showValueOnly = false);
};

#endif /* __cplusplus */

#endif /* __ETK_SPIN_CONTROL_H__ */

