#include <be/support/SupportDefs.h>

#ifndef __LITE_BEAPI_BUILD_H__
#define __LITE_BEAPI_BUILD_H__

#define B_BEOS_VERSION_4	0x0400
#define B_BEOS_VERSION_4_5	0x0450
#define B_BEOS_VERSION_5	0x0500
#define B_BEOS_VERSION_MAUI	0x0500
#define B_BEOS_VERSION_5_0_4	0x0504
#define B_BEOS_VERSION_DANO	0x0510

#define B_BEOS_VERSION		0x0000

#endif /* __LITE_BEAPI_BUILD_H__ */

