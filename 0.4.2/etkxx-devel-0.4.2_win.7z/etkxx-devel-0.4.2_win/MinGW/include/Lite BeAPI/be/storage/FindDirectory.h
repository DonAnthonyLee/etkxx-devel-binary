#ifndef __LITE_BEAPI_FIND_DIRECTORY_H__
#define __LITE_BEAPI_FIND_DIRECTORY_H__

#include <be/support/String.h>
#include <be/storage/Path.h>

#define directory_which			e_directory_which

#define B_BEOS_BOOT_DIRECTORY		E_BOOT_DIRECTORY
#define B_BEOS_APPS_DIRECTORY		E_APPS_DIRECTORY
#define B_BEOS_BIN_DIRECTORY		E_BIN_DIRECTORY
#define B_BEOS_LIB_DIRECTORY		E_LIB_DIRECTORY
#define B_BEOS_ETC_DIRECTORY		E_ETC_DIRECTORY
#define B_BEOS_ADDONS_DIRECTORY		E_ADDONS_DIRECTORY
#define B_COMMON_BOOT_DIRECTORY		E_BOOT_DIRECTORY
#define B_COMMON_APPS_DIRECTORY		E_APPS_DIRECTORY
#define B_COMMON_BIN_DIRECTORY		E_BIN_DIRECTORY
#define B_COMMON_LIB_DIRECTORY		E_LIB_DIRECTORY
#define B_COMMON_ETC_DIRECTORY		E_ETC_DIRECTORY
#define B_COMMON_ADDONS_DIRECTORY	E_ADDONS_DIRECTORY
#define B_COMMON_TEMP_DIRECTORY		E_TEMP_DIRECTORY

#define B_USER_DIRECTORY		E_USER_DIRECTORY
#define B_USER_CONFIG_DIRECTORY		E_USER_CONFIG_DIRECTORY
#define B_USER_BIN_DIRECTORY		E_USER_BIN_DIRECTORY
#define B_USER_LIB_DIRECTORY		E_USER_LIB_DIRECTORY
#define B_USER_SETTINGS_DIRECTORY	E_USER_ETC_DIRECTORY
#define B_USER_ADDONS_DIRECTORY		E_USER_ADDONS_DIRECTORY

#ifndef dev_t
#define e_dev_t dev_t
#endif

#define BVolume				EVolume

// functions

#ifdef __cplusplus

inline status_t find_directory(directory_which which,
			       BPath *path,
			       bool create_it = false,
			       BVolume *vol = NULL)
{
	if(create_it || vol != NULL || path == NULL) return B_ERROR;
	return e_find_directory(which, &path);
}

#endif /* __cplusplus */

extern "C" {

#if 0
inline status_t find_directory(directory_which which,
			       dev_t device,
			       bool create_it,
			       char *returned_path,
			       int32 path_length)
{
	if(create_it || returned_path == NULL || path_length <= 0) return B_ERROR;

	BPath path;
	status_t st = e_find_directory(which, &path);
	if(st != B_OK) return st;

	BString str(path.Path());
	bzero(returned_path, path_length);
	str.CopyInto(returned_path, path_length, 0);

	return B_OK;
}
#endif

} // extern "C"

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_FIND_DIRECTORY_H__ */

