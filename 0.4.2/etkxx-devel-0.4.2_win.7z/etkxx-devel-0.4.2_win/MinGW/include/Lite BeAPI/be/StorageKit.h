#ifndef __LITE_BEAPI_STORAGE_KIT_H__
#define __LITE_BEAPI_STORAGE_KIT_H__

#include <be/storage/StorageDefs.h>
#include <be/storage/Entry.h>
#include <be/storage/Path.h>
#include <be/storage/File.h>
#include <be/storage/FindDirectory.h>

#endif /* __LITE_BEAPI_STORAGE_KIT_H__ */

