#ifndef __LITE_BEAPI_CURSOR_H__
#define __LITE_BEAPI_CURSOR_H__

#include <be/support/SupportDefs.h>

#ifdef __cplusplus

// class
#define BCursor				ECursor

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_CURSOR_H__ */

