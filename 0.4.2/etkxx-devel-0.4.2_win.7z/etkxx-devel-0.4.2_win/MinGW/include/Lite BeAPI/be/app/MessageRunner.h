#ifndef __LITE_BEAPI_MESSAGE_RUNNER_H__
#define __LITE_BEAPI_MESSAGE_RUNNER_H__

#include <be/app/Messenger.h>

#ifdef __cplusplus

// class
#define BMessageRunner			EMessageRunner

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_MESSAGE_RUNNER_H__ */

