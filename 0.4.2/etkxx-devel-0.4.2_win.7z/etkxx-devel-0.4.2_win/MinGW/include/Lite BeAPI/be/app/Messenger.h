#ifndef __LITE_BEAPI_MESSENGER_H__
#define __LITE_BEAPI_MESSENGER_H__

#include <be/app/Handler.h>

#ifdef __cplusplus

// class
#define BMessenger			EMessenger

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_MESSENGER_H__ */

