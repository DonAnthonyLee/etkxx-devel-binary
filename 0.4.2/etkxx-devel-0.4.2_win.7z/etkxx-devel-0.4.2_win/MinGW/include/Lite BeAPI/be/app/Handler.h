#ifndef __LITE_BEAPI_HANDLER_H__
#define __LITE_BEAPI_HANDLER_H__

#include <be/app/AppDefs.h>
#include <be/support/Locker.h>
#include <be/app/Message.h>
#include <be/app/Looper.h>

#ifdef __cplusplus

// class
#define BHandler			EHandler

#endif /* __cplusplus */

/* others */

#endif /* __LITE_BEAPI_HANDLER_H__ */

