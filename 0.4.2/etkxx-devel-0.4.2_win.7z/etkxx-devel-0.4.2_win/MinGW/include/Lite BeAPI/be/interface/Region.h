#ifndef __LITE_BEAPI_REGION_H__
#define __LITE_BEAPI_REGION_H__

#include <be/interface/Rect.h>

#ifdef __cplusplus

// class
#define BRegion		ERegion

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_REGION_H__ */

