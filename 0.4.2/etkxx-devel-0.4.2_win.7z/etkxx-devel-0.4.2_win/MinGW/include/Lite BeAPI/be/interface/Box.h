#ifndef __LITE_BEAPI_BOX_H__
#define __LITE_BEAPI_BOX_H__

#include <be/interface/View.h>

#ifdef __cplusplus

// class
#define BBox	EBox

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_BOX_H__ */

