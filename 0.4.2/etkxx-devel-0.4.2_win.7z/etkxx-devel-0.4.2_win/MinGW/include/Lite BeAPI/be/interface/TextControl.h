#ifndef __LITE_BEAPI_TEXT_CONTROL_H__
#define __LITE_BEAPI_TEXT_CONTROL_H__

#include <be/interface/Control.h>
#include <be/interface/TextView.h>

#ifdef __cplusplus

// class
#define BTextControl		ETextControl

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_TEXT_CONTROL_H__ */

