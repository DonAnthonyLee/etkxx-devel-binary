#ifndef __LITE_BEAPI_STRING_VIEW_H__
#define __LITE_BEAPI_STRING_VIEW_H__

#include <be/interface/View.h>

#ifdef __cplusplus

// class
#define BStringView	EStringView

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_STRING_VIEW_H__ */

