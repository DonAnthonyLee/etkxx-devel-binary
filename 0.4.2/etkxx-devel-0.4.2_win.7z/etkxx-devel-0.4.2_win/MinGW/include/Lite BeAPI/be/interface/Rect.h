#ifndef __LITE_BEAPI_RECT_H__
#define __LITE_BEAPI_RECT_H__

#include <be/interface/Point.h>

#ifdef __cplusplus

// class
#define BRect	ERect

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_RECT_H__ */

