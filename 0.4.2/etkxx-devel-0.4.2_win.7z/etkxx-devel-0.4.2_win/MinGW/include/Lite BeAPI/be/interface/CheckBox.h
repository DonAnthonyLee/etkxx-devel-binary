#ifndef __LITE_BEAPI_CHECK_BOX_H__
#define __LITE_BEAPI_CHECK_BOX_H__

#include <be/interface/Control.h>

#ifdef __cplusplus

// class
#define BCheckBox	ECheckBox

#endif /* __cplusplus */

#endif /* __LITE_BEAPI_CHECK_BOX_H__ */

